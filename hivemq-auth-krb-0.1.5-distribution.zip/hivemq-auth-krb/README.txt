
== HiveMQ Kerberos Auth Extension ==
A Factory+ Kerberos authentication & authorisation plugin for HiveMQ

*License*: MIT